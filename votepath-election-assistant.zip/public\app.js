const messagesEl = document.querySelector("#messages");
const form = document.querySelector("#chat-form");
const input = document.querySelector("#user-input");
const sendButton = form.querySelector("button");
const quickButtons = document.querySelectorAll("[data-prompt]");

const chatHistory = [];

const welcomeMessage = `Hello, I am VotePath.

Choose a topic or ask your own question. I can explain voter registration, election timelines, polling day steps, counting, and result declaration in a neutral step-by-step way.`;

function addMessage(role, text, className = "") {
  const node = document.createElement("div");
  node.className = `message ${role} ${className}`.trim();
  node.textContent = text;
  messagesEl.appendChild(node);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return node;
}

function toGeminiRole(role) {
  return role === "assistant" ? "model" : "user";
}

async function askAssistant(prompt) {
  const message = prompt.trim();
  if (!message) return;

  addMessage("user", message);
  chatHistory.push({ role: "user", parts: [{ text: message }] });
  input.value = "";
  sendButton.disabled = true;
  const loading = addMessage("assistant", "Thinking through the process...", "loading");

  try {
    const response = await fetch("/api/assistant", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        history: chatHistory.slice(0, -1).map(item => ({
          role: toGeminiRole(item.role),
          parts: item.parts
        }))
      })
    });

    const data = await response.json();
    loading.remove();
    const answer = data.answer || "I could not answer that. Please try again.";
    addMessage("assistant", answer);
    chatHistory.push({ role: "assistant", parts: [{ text: answer }] });
  } catch (error) {
    loading.remove();
    addMessage(
      "assistant",
      "I could not reach the assistant service. Please check the server and try again."
    );
  } finally {
    sendButton.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  askAssistant(input.value);
});

quickButtons.forEach(button => {
  button.addEventListener("click", () => askAssistant(button.dataset.prompt));
});

input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

addMessage("assistant", welcomeMessage);
